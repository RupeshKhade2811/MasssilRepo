package com.factory.appraisal.vehiclesearchapp.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.Max;
import javax.validation.constraints.Size;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AppraisalVehicleCard {

    private Long appraisalReferenceId;
    private String make ;
    private String  model ;
    private Long miles;
    private String appraisalValue;
    private String createdBy;
    private Long year;
    private String image;


}
