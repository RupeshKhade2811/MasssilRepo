package com.factory.appraisal.vehiclesearchapp.repository;
//Author:Rupesh khade
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public interface EAppraiseVehicleRepo extends JpaRepository<EAppraiseVehicle,Long> {
     EAppraiseVehicle findByVinNumber(String vinNum);
     EAppraiseVehicle findByVinNumberAndValidIsTrue(String vinNumber);

    Page<EAppraiseVehicle> findAllByValidIsTrueOrderByCreatedOnDesc(Pageable pageable);
     Page<EAppraiseVehicle> findAllByValidIsTrueAndUserUserIdOrderByCreatedOnDesc(Long userId, Pageable pageable);
     List<EAppraiseVehicle> findAllByValidIsTrueAndUserUserId(Long userId);

    // Page<EAppraiseVehicle> findAllByValidIsTrueAndDealerDealerIdOrderByCreatedOnDesc(Long dealerId, Pageable pageable);
}
