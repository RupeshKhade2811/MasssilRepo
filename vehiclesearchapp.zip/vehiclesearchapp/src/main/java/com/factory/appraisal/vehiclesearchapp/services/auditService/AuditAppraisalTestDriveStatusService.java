package com.factory.appraisal.vehiclesearchapp.services.auditService;
//Auther :Rupesh khade

import java.util.ArrayList;
import java.util.Map;

public interface AuditAppraisalTestDriveStatusService {
    ArrayList<Map<String,Object>> getAuditedData(String field,Long id,Integer offset);
}
