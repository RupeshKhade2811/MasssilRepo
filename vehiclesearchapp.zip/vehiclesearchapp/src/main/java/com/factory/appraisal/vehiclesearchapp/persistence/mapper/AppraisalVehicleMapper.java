package com.factory.appraisal.vehiclesearchapp.persistence.mapper;
//@author:Rupesh Khade

import com.factory.appraisal.vehiclesearchapp.dto.*;

import com.factory.appraisal.vehiclesearchapp.persistence.model.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AppraisalVehicleMapper {
    AppraiseVehicle eAppraiseVehicleToAppraiseVehicle (EAppraiseVehicle eAppraiseVehicle);
    EAppraiseVehicle appraiseVehicleToEAppraiseVehicle(AppraiseVehicle appraiseVehicle);
    List<EAppraiseVehicle> listAppraiseVehicleToListEAppraiseVehicle (List<AppraiseVehicle> appraiseVehicleList);
    List<AppraiseVehicle> listEAppraiseVehiclesToListAppraiseVehicle (List<EAppraiseVehicle> eAppraiseVehicleList);


    AppraisalVehicleCard eAppraiseVehicleToAppraisalVehicleCard(EAppraiseVehicle eAppraiseVehicle);
    List<AppraisalVehicleCard> listEAppraiseVehicleToListAppraisalVehicleCard (List<EAppraiseVehicle> eAppraiseVehicleList);

    AppraisalVehicleAcCondition eAppraisalVehicleAcConditionToAppraisalVehicleAcCondition(EAppraisalVehicleAcCondition eAppraisalVehicleAcCondition);
    EAppraisalVehicleAcCondition appraisalVehicleAcConditionToEAppraisalVehicleAcCondition(AppraisalVehicleAcCondition appraisalVehicleAcCondition);

    AppraisalVehicleInteriorCondition eAppraisalVehicleInteriorConditionToAppraisalVehicleInteriorCondition (EAppraisalVehicleInteriorCondition eAppraisalVehicleInteriorCondition);
    EAppraisalVehicleInteriorCondition appraisalVehicleInteriorConditionToEAppraisalVehicleInteriorCondition(AppraisalVehicleInteriorCondition appraisalVehicleInteriorCondition);


    AppraisalVehicleOilCondition eAppraisalVehicleOilConditionToAppraisalVehicleOilCondition(EAppraisalVehicleOilCondition eAppraisalVehicleOilCondition);
    EAppraisalVehicleOilCondition appraisalVehicleOilConditionToEAppraisalVehicleOilCondition(AppraisalVehicleOilCondition appraisalVehicleOilCondition);

    AppraisalVehicleStereoStatus eAppraisalVehicleStereoStatusToAppraisalVehicleStereoStatus(EAppraisalVehicleStereoStatus eAppraisalVehicleStereoStatus);
    EAppraisalVehicleStereoStatus appraisalVehicleStereoStatusToEAppraisalVehicleStereoStatus(AppraisalVehicleStereoStatus appraisalVehicleStereoStatus);

    AppraisalVehicleTireCondition eAppraisalVehicleTireConditionToAppraisalVehicleTireCondition (EAppraisalVehicleTireCondition eAppraisalVehicleTireCondition);
    EAppraisalVehicleTireCondition appraisalVehicleTireConditionToEAppraisalVehicleTireCondition(AppraisalVehicleTireCondition appraisalVehicleTireCondition);

    EVehicleDrivingWarnLightStatus vehicleDrivingWarnLightStatusToEVehicleDrivingWarnLightStatus (VehicleDrivingWarnLightStatus vehicleDrivingWarnLightStatus);
    VehicleDrivingWarnLightStatus eVehicleDrivingWarnLightStatusToVehicleDrivingWarnLightStatus(EVehicleDrivingWarnLightStatus eVehicleDrivingWarnLightStatus);


    @Mapping(target = "appraisalVehicleAcCondition",ignore = true)
    @Mapping(target = "appraisalVehicleInteriorCondition",ignore = true)
    @Mapping(target = "appraisalVehicleOilCondition",ignore = true)
    @Mapping(target = "appraisalVehicleStereoStatus",ignore = true)
    @Mapping(target = "appraisalVehicleTireCondition",ignore = true)
    @Mapping(target = "vehicleDrivingWarnLightStatus",ignore = true)
    AppraisalTestDriveStatusWithBaseClass EAppraisalTestDriveStatusToAppraisalTestDriveStatusWithBaseClass(EAppraisalTestDriveStatus eAppraisalTestDrivingStatus);  //ignore  due to  recursion problem in mapstruct, entities having bidirectional relationship

    @Mapping(target ="appraisalRef",expression = "java( mapAppraisalRef(appraisalTestDrivingStatus.getAppraisalRef()))")
    @Mapping(target ="appraisalRef.appraisalTestDriveStatus",ignore = true)


    @Mapping(target ="appraisalVehicleAcCondition",expression = "java( mapAppraisalVehicleAcCondition(appraisalTestDrivingStatus.getAppraisalVehicleAcCondition()))")
    @Mapping(target ="appraisalVehicleAcCondition.vehicleStatus",ignore = true)

    @Mapping(target ="appraisalVehicleInteriorCondition",expression = "java( mapAppraisalVehicleInteriorCondition(appraisalTestDrivingStatus.getAppraisalVehicleInteriorCondition()))")
    @Mapping(target ="appraisalVehicleInteriorCondition.vehicleStatus",ignore = true)

    @Mapping(target ="appraisalVehicleOilCondition",expression = "java(  mapAppraisalVehicleOilCondition(appraisalTestDrivingStatus.getAppraisalVehicleOilCondition()))")
    @Mapping(target ="appraisalVehicleOilCondition.vehicleStatus",ignore = true)

    @Mapping(target ="appraisalVehicleStereoStatus",expression = "java( mapAppraisalVehicleStereoStatus(appraisalTestDrivingStatus.getAppraisalVehicleStereoStatus()))")
    @Mapping(target ="appraisalVehicleStereoStatus.vehicleStatus",ignore = true)

    @Mapping(target ="appraisalVehicleTireCondition",expression = "java( mapAppraisalVehicleTireCondition(appraisalTestDrivingStatus.getAppraisalVehicleTireCondition()))")
    @Mapping(target ="appraisalVehicleTireCondition.vehicleStatus",ignore = true)

    @Mapping(target ="vehicleDrivingWarnLightStatus",expression = "java( mapVehicleDrivingWarnLightStatus(appraisalTestDrivingStatus.getVehicleDrivingWarnLightStatus()))")
    @Mapping(target ="vehicleDrivingWarnLightStatus.vehicleStatus",ignore = true)

    EAppraisalTestDriveStatus AppraisalTestDriveStatusWithBaseClassToEAppraisalTestDriveStatus(AppraisalTestDriveStatusWithBaseClass appraisalTestDrivingStatus);



    default EAppraisalVehicleAcCondition mapAppraisalVehicleAcCondition(AppraisalVehicleAcCondition appraisalVehicleAcCondition){

        return appraisalVehicleAcConditionToEAppraisalVehicleAcCondition(appraisalVehicleAcCondition);
    }
    default EAppraisalVehicleInteriorCondition mapAppraisalVehicleInteriorCondition(AppraisalVehicleInteriorCondition interiorCondition){

        return appraisalVehicleInteriorConditionToEAppraisalVehicleInteriorCondition(interiorCondition);
    }
    default EAppraisalVehicleOilCondition mapAppraisalVehicleOilCondition(AppraisalVehicleOilCondition oilCondition){

        return appraisalVehicleOilConditionToEAppraisalVehicleOilCondition(oilCondition);
    }
    default EAppraisalVehicleStereoStatus mapAppraisalVehicleStereoStatus(AppraisalVehicleStereoStatus vehicleStereoStatus){

        return appraisalVehicleStereoStatusToEAppraisalVehicleStereoStatus(vehicleStereoStatus );
    }
    default EAppraisalVehicleTireCondition mapAppraisalVehicleTireCondition(AppraisalVehicleTireCondition tireCondition){

        return appraisalVehicleTireConditionToEAppraisalVehicleTireCondition(tireCondition);
    }
    default EVehicleDrivingWarnLightStatus mapVehicleDrivingWarnLightStatus(VehicleDrivingWarnLightStatus warnLightStatus){

        return vehicleDrivingWarnLightStatusToEVehicleDrivingWarnLightStatus(warnLightStatus);
    }


}
