package com.factory.appraisal.vehiclesearchapp.persistence.mapper;
//@author:Rupesh Khade

import com.factory.appraisal.vehiclesearchapp.dto.AppraiseVehicle;

import com.factory.appraisal.vehiclesearchapp.persistence.model.*;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AppraisalVehicleMapper {


    AppraiseVehicle modelToDto(EAppraiseVehicle eAppraiseVehicle);

    EAppraiseVehicle dtoToModel(AppraiseVehicle appraiseVehicle);

    List<EAppraiseVehicle> dtosToModels(List<AppraiseVehicle> appraiseVehicleList);

    List<AppraiseVehicle> modelsToDtos(List<EAppraiseVehicle> eAppraiseVehicleList);




}
