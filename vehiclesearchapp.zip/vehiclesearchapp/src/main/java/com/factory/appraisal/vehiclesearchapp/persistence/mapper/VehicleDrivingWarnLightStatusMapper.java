package com.factory.appraisal.vehiclesearchapp.persistence.mapper;
//Author:Yudhister vijay

import com.factory.appraisal.vehiclesearchapp.dto.VehicleDrivingWarnLightStatus;

import com.factory.appraisal.vehiclesearchapp.persistence.model.EVehicleDrivingWarnLightStatus;
import org.mapstruct.Mapper;


@Mapper(componentModel = "spring")
public interface VehicleDrivingWarnLightStatusMapper {



    EVehicleDrivingWarnLightStatus dtoToModel (VehicleDrivingWarnLightStatus vehicleDrivingWarnLightStatus);


    VehicleDrivingWarnLightStatus modelToDto(EVehicleDrivingWarnLightStatus eVehicleDrivingWarnLightStatus);




}

