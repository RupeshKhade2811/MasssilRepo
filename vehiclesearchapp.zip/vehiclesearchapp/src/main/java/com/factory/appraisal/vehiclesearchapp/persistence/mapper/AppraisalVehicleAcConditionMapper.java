package com.factory.appraisal.vehiclesearchapp.persistence.mapper;

//@author:Rupesh Khade

import com.factory.appraisal.vehiclesearchapp.dto.AppraisalVehicleAcCondition;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraisalVehicleAcCondition;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface AppraisalVehicleAcConditionMapper {
    AppraisalTestDrivingStatusWithBaseClassMapper INSTANCE = Mappers.getMapper(AppraisalTestDrivingStatusWithBaseClassMapper.class);



    AppraisalVehicleAcCondition modelToDto(EAppraisalVehicleAcCondition eAppraisalVehicleAcCondition);


    EAppraisalVehicleAcCondition dtoToModel(AppraisalVehicleAcCondition appraisalVehicleAcCondition);   //dto coming from ui has all data to save to entity

}
