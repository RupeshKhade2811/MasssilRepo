package com.factory.appraisal.vehiclesearchapp.controller;
//@Author:Rupesh khade

import com.factory.appraisal.vehiclesearchapp.persistence.model.ESignDet;

import com.factory.appraisal.vehiclesearchapp.services.ESignDetServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ESignDetController {
    @Autowired
    private ESignDetServiceImpl service;
    @PostMapping("/addESignDet")
    public ESignDet addESignDet(@RequestBody  ESignDet eSignDet){
       return service.addESignDet(eSignDet);



    }
}
