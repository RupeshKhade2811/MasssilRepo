package com.factory.appraisal.vehiclesearchapp.services.crudServices;
//Author:Rupesh khade,yogesh,kalyan,vijay

import com.factory.appraisal.vehiclesearchapp.Constants;
import com.factory.appraisal.vehiclesearchapp.dto.AppraisalVehicleCard;
import com.factory.appraisal.vehiclesearchapp.dto.AppraiseVehicle;

import com.factory.appraisal.vehiclesearchapp.dto.PageInfo;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.*;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.repository.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.Size;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@Service
public class EAppraiseVehicleServiceImpl implements EAppraiseVehicleService {
    @Autowired
    private EAppraiseVehicleRepo eAppraiseVehicleRepo;
    @Autowired

    private EUserRegistrationRepo userRegistrationRepo;

    @Autowired
    private  AppraisalVehicleCardMapper cardMapper;
    @Autowired
    EAppraisalTestDriveStatusRepo eAppraisalTestDriveStatusRepo;
    @Autowired
    private AppraisalVehicleMapper appraisalVehicleMapper;
    @Autowired
    private AppraisalTestDrivingStatusWithBaseClassMapper appraisalTestDrivingStatusMapper;
    @Autowired
    private AppraisalVehicleAcConditionMapper acConditionMapper;
    @Autowired
    private AppraisalVehicleOilConditionMapper oilConditionMapper;
    @Autowired
    private AppraisalVehicleInteriorConditionMapper interiorConditionMapper;
    @Autowired
    private AppraisalVehicleStereoStatusMapper stereoStatusMapper;
    @Autowired
    private AppraisalVehicleTireConditionMapper appraisalVehicleTireConditionMapper;
    @Autowired
    private VehicleDrivingWarnLightStatusMapper warnLightStatusMapper;
    @Autowired
    private EAppraisalVehicleAcConditionRepo eAppraisalVehicleAcConditionRepo;


    @Override
    public  List<AppraiseVehicle>  GetAppraisals(Integer pageNumber) {

        Pageable pageable = PageRequest.of(pageNumber, 10,Sort.by("createdOn").descending());
        Page<EAppraiseVehicle> pageResult = eAppraiseVehicleRepo.findAllByValidIsTrueOrderByCreatedOnDesc(pageable);

        List<EAppraiseVehicle>apv = pageResult.toList();


        List<AppraiseVehicle> appraiseVehicleDtos= appraisalVehicleMapper.modelsToDtos(apv);

        return appraiseVehicleDtos;
    }


    @Override
    public String addAppraiseVehicle(AppraiseVehicle appraiseVehicle) {


       EAppraiseVehicle eAppraiseVehicle= appraisalVehicleMapper.dtoToModel(appraiseVehicle);

        eAppraiseVehicle.setDealer(userRegistrationRepo.getOne(32l).getDealer());
        eAppraiseVehicle.setUser(userRegistrationRepo.getOne(32l));

        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalRef(eAppraiseVehicle);
        eAppraiseVehicle.setAppraisalTestDriveStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());

        eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition().setVehicleStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());
        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition());

        eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition().setVehicleStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());
        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalVehicleInteriorCondition(eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition());

        eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition().setVehicleStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());
        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalVehicleOilCondition(eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition());

        eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus().setVehicleStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());
        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalVehicleStereoStatus(eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus());

        eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleTireCondition().setVehicleStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());
        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalVehicleTireCondition(eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleTireCondition());

        eAppraiseVehicle.getAppraisalTestDriveStatus().getVehicleDrivingWarnLightStatus().setVehicleStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());
        eAppraiseVehicle.getAppraisalTestDriveStatus().setVehicleDrivingWarnLightStatus(eAppraiseVehicle.getAppraisalTestDriveStatus().getVehicleDrivingWarnLightStatus());



       EAppraiseVehicle eAppraiseVehicle1=eAppraiseVehicleRepo.save(eAppraiseVehicle);//4


        return "saved successfully";

    }
    @Override
    public AppraiseVehicle findByVinNumber(String vinNum) {
        EAppraiseVehicle apv = eAppraiseVehicleRepo.findByVinNumberAndValidIsTrue(vinNum);
        if(apv!=null) {

            AppraiseVehicle appraiseVehicleDto = appraisalVehicleMapper.modelToDto(apv);

            return appraiseVehicleDto;
        }
        else throw new RuntimeException("Did not find AppraisalVehicle of  - " + vinNum);

    }

    @Override
    public AppraiseVehicle updateAppraisalVehicle(AppraiseVehicle eAppraiseVehicledto){


        EAppraiseVehicle vehicle = eAppraiseVehicleRepo.findByVinNumber(eAppraiseVehicledto.getVinNumber());
        if(vehicle!=null){


             return null;
        }

       else throw new RuntimeException("Did not find AppraisalVehicle of "+eAppraiseVehicledto.getVinNumber() );

    }

    @Override
    public AppraiseVehicle deleteAppraisalVehicle(String vinNum) {
        EAppraiseVehicle byVinNumber = eAppraiseVehicleRepo.findByVinNumber(vinNum);

        if(byVinNumber!=null && byVinNumber.getValid()==true) {
            byVinNumber.setValid(false);
            eAppraiseVehicleRepo.save(byVinNumber);

            return appraisalVehicleMapper.modelToDto(byVinNumber);
        }
        throw  new RuntimeException("Can not find Appraisal for "+vinNum);
    }




    @Override
    public AppraisalVehicleCard findByVinNumberCard(String vinNo) {

        EAppraiseVehicle vehicle = eAppraiseVehicleRepo.findByVinNumberAndValidIsTrue(vinNo.toUpperCase());

        if(vehicle!=null){
            AppraisalVehicleCard card = cardMapper.modelToDto(vehicle);


            card.setImage(Constants.ImagesToUI_PATH +vehicle.getAppraisalReferenceId());

            return card;
        }

        else throw new RuntimeException();

    }

    @Override
    public ResponseEntity<List<AppraisalVehicleCard>> findAllCards(Long userId,Integer pageNumber) throws JsonProcessingException {

        int pageSize = 10;
        List<EAppraiseVehicle> all = eAppraiseVehicleRepo.findAllByValidIsTrueAndUserUserId(userId);

        PageInfo pageInfo = new PageInfo();
        pageInfo.setRecordsPerPage(pageSize);
        pageInfo.setTotalRecords(all.size());
        pageNumber = pageNumber - 1;

        int pages=all.size()/pageSize;
        if(pages>=pageNumber) {


            if (userId > 0) {


                Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by("createdOn").descending());
                // Page<EAppraiseVehicle> pageResult = eAppraiseVehicleRepo.findAllByValidIsTrueOrderByCreatedOnDesc(pageable);
                Page<EAppraiseVehicle> pageResult = eAppraiseVehicleRepo.findAllByValidIsTrueAndUserUserIdOrderByCreatedOnDesc(userId, pageable);


                List<EAppraiseVehicle> apv = pageResult.toList();
                if (apv.size() != 0) {

                    List<AppraisalVehicleCard> appraiseVehicleDtos = cardMapper.modelsToDtos(apv);

                    ArrayList<EAppraiseVehicle> al1 = new ArrayList<>(apv);

                    ArrayList<AppraisalVehicleCard> al2 = new ArrayList<>(appraiseVehicleDtos);
                    for (int i = 0; i < al1.size(); i++) {
                        al2.get(i).setImage(Constants.ImagesToUI_PATH + al1.get(i).getAppraisalReferenceId());
                    }


                    // Set the PageInfo in the response headers
                    HttpHeaders headers = new HttpHeaders();
                    headers.add("Page-Info", new ObjectMapper().writeValueAsString(pageInfo));
                    // Return the ResponseEntity with headers and body
                    return new ResponseEntity<>(al2, headers, HttpStatus.OK);

                } else
                    throw new IllegalArgumentException(" AppraisalsCards not available for given userId:= " + userId);

            } else throw new IllegalArgumentException("Invalid UserId..!");

        }
        else throw new IllegalArgumentException("AppraisalCards not available for given page number");

    }


    public byte[] downloadImageFromFileSystem(Long appraisalReferenceId) throws IOException {
        EAppraiseVehicle  vehicle= eAppraiseVehicleRepo.findById(appraisalReferenceId).orElse(null);
        if(vehicle!=null){


            String filePath= Constants.FOLDER_PATH +vehicle.getAppraisalTestDriveStatus().getRearRightImage();
            byte[] images = Files.readAllBytes(new File(filePath).toPath());//**************************Reading from folder
            return images;

        }
        else throw new RuntimeException("ImageNot found for given Id");



    }
    @Override
    public Map<Integer,String> imageUpload(MultipartFile file1,MultipartFile file2,MultipartFile file3,MultipartFile file4) throws IOException {

        Map<Integer, String> map = new TreeMap<>();

        for (int i = 1; i <= 4; i++) {
            MultipartFile file = null;
            switch (i) {
                case 1:
                    file = file1;
                    break;
                case 2:
                    file = file2;
                    break;
                case 3:
                    file = file3;
                    break;
                case 4:
                    file = file4;
                    break;
            }
            if (file != null) {
                String extension = FilenameUtils.getExtension(file.getOriginalFilename());
                String filename = UUID.randomUUID().toString() + "." + extension;
                Path filePath = Paths.get(Constants.FOLDER_PATH + filename);
                Files.write(filePath, file.getBytes());
                map.put(i, filename);
            }
        }


        return map;
    }
}
