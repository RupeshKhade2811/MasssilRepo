package com.factory.appraisal.vehiclesearchapp.persistence.mapper;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface AppraisalTestDriveStatus {

}
