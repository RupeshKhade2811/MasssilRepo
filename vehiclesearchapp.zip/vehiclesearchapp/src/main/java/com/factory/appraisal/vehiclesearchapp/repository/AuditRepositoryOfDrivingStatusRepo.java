package com.factory.appraisal.vehiclesearchapp.repository;

import java.util.List;

public interface AuditRepositoryOfDrivingStatusRepo {
    List<Object[]> executeSqlQuery(String field, Long id, Integer offset);
}
