package com.factory.appraisal.vehiclesearchapp.services.auditService;
//Author:Rupesh Khade
import com.factory.appraisal.vehiclesearchapp.repository.AuditRepositoryOfDrivingStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

@Service
public class AuditAppraisalTestDriveStatusServiceImpl implements AuditAppraisalTestDriveStatusService {
    @Autowired
    private AuditRepositoryOfDrivingStatus auditRepo;
    @Override
    public ArrayList<Map<String, Object>> getAuditedData(String field,Long id,Integer offset) {

        List<Object[]> resultList= auditRepo.executeSqlQuery(field,id,offset);

        ArrayList<Object[]>al1=new ArrayList<>(resultList);

        ArrayList<Map<String,Object>> al2= new ArrayList<>();

        String[]key =new String[]{"1.vehStatusId","2.rev","3.revType","4.oldValue","5.newValue","6.modifiedBy","7.modifiedOn"};


        for (Object[] ob1:al1) {

            Map<String,Object> map=new TreeMap<>();

            for(int i=0;i<ob1.length;i++){

                map.put(key[i],ob1[i]);
            }
            al2.add(map);
        }

        return al2;
    }
}
