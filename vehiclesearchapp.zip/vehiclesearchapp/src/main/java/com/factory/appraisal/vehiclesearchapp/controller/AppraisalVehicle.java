package com.factory.appraisal.vehiclesearchapp.controller;
//@author:Rupesh Khade

import com.factory.appraisal.vehiclesearchapp.dto.AppraisalVehicleCard;
import com.factory.appraisal.vehiclesearchapp.dto.AppraiseVehicle;

import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.responseHandler.ApiResponseHandler;
import com.factory.appraisal.vehiclesearchapp.services.crudServices.EAppraiseVehicleServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import springfox.documentation.annotations.ApiIgnore;

import javax.validation.Valid;

import javax.validation.constraints.Min;
import javax.validation.constraints.Size;
import java.io.IOException;


import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "http://localhost:8000")
@RequestMapping("/api/appraisal")
public class AppraisalVehicle {

    @Autowired
    private EAppraiseVehicleServiceImpl service;

    @ApiIgnore

    @ApiOperation(value = "Add Appraisal", response = AppraiseVehicle.class)
    @PostMapping("/addAppraiseVehicle")
    public ResponseEntity<?> addAppraiseVehicle(@RequestBody  AppraiseVehicle appraiseVehicle) {
        String message = service.addAppraiseVehicle(appraiseVehicle);

        return  ApiResponseHandler.generateResponse(HttpStatus.OK,message);

    }
    @ApiIgnore
    @GetMapping("/getAppraisals/{pageNumber}")
    public ResponseEntity<?> getAppraisals(@PathVariable @Size(min=1,message = "page number must be positive Integer") Integer pageNumber){

    List<AppraiseVehicle> apv = service.GetAppraisals(pageNumber);

    return new ResponseEntity<>(apv, HttpStatus.ACCEPTED);

    }
    @ApiIgnore
    @ApiOperation(value = "Get Appraisal by vinNumber", response = EAppraiseVehicle.class)
    @GetMapping(value = "/getAppraisal/{byVinNum}")
    public  ResponseEntity<?> showAppraisalVehicle(@PathVariable @Size(min=17,message = "Vin number must contain 17 characters") String byVinNum){

        return new ResponseEntity<>(service.findByVinNumber(byVinNum),HttpStatus.ACCEPTED);
    }

    @ApiIgnore
    @ApiOperation(value = "Update Appraisal  by vinNumber", response = AppraiseVehicle.class)
    @PutMapping("/updateAppraisalVehicle/{vinNum}")
    public ResponseEntity<AppraiseVehicle> updateAppraisalVehicle( @RequestBody @Valid AppraiseVehicle appraiseVehicle){
        AppraiseVehicle appraiseVehicleDto= service.updateAppraisalVehicle(appraiseVehicle);
        return new ResponseEntity<>(appraiseVehicleDto,HttpStatus.ACCEPTED);
    }

    @ApiIgnore
    @ApiOperation(value = "Delete Appraisal  by vinNumber")
    @DeleteMapping("/deleteAppraisal/{vinNum}")
    public ResponseEntity<AppraiseVehicle> deleteAppraisal(@PathVariable  @Size(min=17,message = "Vin number must contain 17 characters") String vinNum){
        return new ResponseEntity<>(service.deleteAppraisalVehicle(vinNum),HttpStatus.ACCEPTED);


    }


    @ApiOperation(value = "get Appraisals cards by user id ", response = AppraisalVehicleCard.class)
    @GetMapping("/getAppraisalsCards/{userId}/{pageNumber}")
    public ResponseEntity<?> getAppraisalsCards(@PathVariable @Min(1) Long userId, @PathVariable @Size(min=1,message = "page number must be positive Integer") Integer pageNumber) throws JsonProcessingException {
        ResponseEntity<List<AppraisalVehicleCard>>apv = service.findAllCards(userId,pageNumber);

        return apv;
    }


   @ApiIgnore
    @GetMapping("/getRRImage/{appraisalReferenceId}")
    public ResponseEntity<?> downloadImageFromFileSystem(@PathVariable Long appraisalReferenceId) throws IOException {
        byte[] bytes = service.downloadImageFromFileSystem(appraisalReferenceId);
        return ResponseEntity.status(HttpStatus.OK)
                .contentType(MediaType.valueOf("image/jpeg"))
                .body(bytes);

    }
    @ApiIgnore
    @ApiOperation(value = "Upload Image and Returns image name", response = ApiResponseHandler.class)
    @PostMapping("/uploadImage")
    public ResponseEntity<?> uploadImage(@RequestParam("image1") MultipartFile file1, @RequestParam("image2")
    MultipartFile file2,@RequestParam("image3") MultipartFile file3,@RequestParam("image4") MultipartFile file4) throws IOException {
        Map<Integer,String> map=service.imageUpload(file1,file2,file3,file4);
        return new ResponseEntity<>(map,HttpStatus.OK);
    }

}
