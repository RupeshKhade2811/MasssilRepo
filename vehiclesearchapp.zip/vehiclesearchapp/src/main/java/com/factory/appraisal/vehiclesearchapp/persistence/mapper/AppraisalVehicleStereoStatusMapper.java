package com.factory.appraisal.vehiclesearchapp.persistence.mapper;


import com.factory.appraisal.vehiclesearchapp.dto.AppraisalVehicleStereoStatus;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraisalVehicleStereoStatus;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface AppraisalVehicleStereoStatusMapper {





    AppraisalVehicleStereoStatus modelToDto(EAppraisalVehicleStereoStatus eAppraisalVehicleStereoStatus);


    EAppraisalVehicleStereoStatus dtoToModel(AppraisalVehicleStereoStatus appraisalVehicleStereoStatus);


}
