package com.factory.appraisal.vehiclesearchapp.services;
//Author:Rupesh khade
import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.*;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.repository.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.apache.commons.io.FilenameUtils;
import java.io.File;
import org.springframework.http.HttpHeaders;

import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@Service
public class EAppraiseVehicleServiceImpl implements EAppraiseVehicleService {
    @Autowired
    EAppraiseVehicleRepo eAppraiseVehicleRepo;
    @Autowired
    EConfigurationCodesRepo eConfigurationCodesRepo;
    @Autowired
    EAppraisalTestDriveStatusRepo eAppraisalTestDriveStatusRepo;
    @Autowired
    EUserRegistrationRepo eUserRegistrationRepo;
    @Autowired
    EDealerRegistrationRepo eDealerRegistrationRepo;
    @Autowired
    private ESignDetRepo eSignDetRepo;
    @Autowired
    private AppraisalVehicleMapper appraisalVehicleMapper;
    @Autowired
    private DealerRegistrationMapper dealerRegistrationMapper;
    @Autowired
    private UserRegistrationMapper userRegistrationMapper;
    @Autowired
    private AppraisalTestDrivingStatusMapper appraisalTestDrivingStatusMapper;
    @Autowired
    private AppraisalVehicleAcConditionMapper acConditionMapper;
    @Autowired
    private ConfigCodesMapper configCodesMapper;
    @Autowired
    private SignDetMapper signDetMapper;

    @Override
    public List<AppraiseVehicle> GetAppraisals(Integer pageNumber, Integer pageSize) {

        Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by("createdOn").descending());
        Page<EAppraiseVehicle> pageResult = eAppraiseVehicleRepo.findAllByValidIsTrueOrderByCreatedOnDesc(pageable);

        List<EAppraiseVehicle>apv = pageResult.toList();


        List<AppraiseVehicle> appraiseVehicleDtos= appraisalVehicleMapper.modelsToDtos(apv);

        ArrayList<EAppraiseVehicle> al1= new ArrayList<>(apv);
        ArrayList<AppraiseVehicle>al2= new ArrayList<>(appraiseVehicleDtos);
        for(int i=0;i<al1.size();i++){
            al2.get(i).setDealer(dealerRegistrationMapper.modeltoDto(al1.get(i).getDealer()));
            al2.get(i).setUser(userRegistrationMapper.modelToDto(al1.get(i).getUser()));
            al2.get(i).setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(al1.get(i).getAppraisalTestDriveStatus()));
            al2.get(i).getUser().setRoleConfig(configCodesMapper.modelToDto(al1.get(i).getUser().getRoleConfig()));
            al2.get(i).setSignDet(signDetMapper.modelToDto(al1.get(i).getSignDet()));
            al2.get(i).getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(acConditionMapper.modelToDto(al1.get(i).getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition()));

        }

        List<AppraiseVehicle> appraiseVehicleDtos1=al2;

        return appraiseVehicleDtos1;
    }

    private final String FOLDER_PATH="C://myfile/";
    @Override
    public AppraiseVehicle addAppraiseVehicle(AppraiseVehicle appraiseVehicle, MultipartFile rightImage) throws IOException {


       EAppraiseVehicle eAppraiseVehicle= appraisalVehicleMapper.dtoToModel(appraiseVehicle);

        String extension = FilenameUtils.getExtension(rightImage.getOriginalFilename());
        String filename = UUID.randomUUID().toString() +"."+ extension;
        Path filePath = Paths.get(FOLDER_PATH + filename);
      //  FileData fileData=fileDataRepository.save(FileData.builder().name(filename).fileType(file.getContentType()).build());

        Files.write(filePath, rightImage.getBytes()); //sending to folder

        eAppraiseVehicle.getAppraisalTestDriveStatus().setRearRightImage(filename);      //setting to object


        eAppraiseVehicle.getDealer().setConfigCodes(eAppraiseVehicle.getUser().getRoleConfig());
        eAppraiseVehicle.getUser().setRoleConfig(eAppraiseVehicle.getUser().getRoleConfig());

        eAppraiseVehicle.getUser().setDealer(eAppraiseVehicle.getDealer());
        eAppraiseVehicle.setUser(eAppraiseVehicle.getUser());
        eAppraiseVehicle.setDealer(eAppraiseVehicle.getDealer());
        eAppraiseVehicle.setAppraisalTestDriveStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());
        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalRef(eAppraiseVehicle);


        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition());
        eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition().setVehicleStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());

        eAppraiseVehicle.getSignDet().setAppraisalReference(eAppraiseVehicle);
        eAppraiseVehicle.setSignDet(eAppraiseVehicle.getSignDet());



        eConfigurationCodesRepo.save(eAppraiseVehicle.getUser().getRoleConfig());//1
        eDealerRegistrationRepo.save(eAppraiseVehicle.getDealer());//2
        eUserRegistrationRepo.save(eAppraiseVehicle.getUser());//3


        EAppraiseVehicle eAppraiseVehicle1=eAppraiseVehicleRepo.save(eAppraiseVehicle);//4
      // eAppraisalTestDriveStatusRepo.save(eAppraiseVehicle.getAppraisalTestDriveStatus());//5


       return appraisalVehicleMapper.modelToDto(eAppraiseVehicle);

    }
    @Override
    public ResponseEntity<String> findByVinNumber(String vinNum) throws IOException {
        EAppraiseVehicle apv = eAppraiseVehicleRepo.findByVinNumberAndValidIsTrue(vinNum);
        if(apv!=null) {

            AppraiseVehicle appraiseVehicleDto = appraisalVehicleMapper.modelToDto(apv);

            appraiseVehicleDto.setDealer(dealerRegistrationMapper.modeltoDto(apv.getDealer()));
            appraiseVehicleDto.setUser(userRegistrationMapper.modelToDto(apv.getUser()));
            appraiseVehicleDto.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(apv.getAppraisalTestDriveStatus()));
            appraiseVehicleDto.getUser().setRoleConfig(configCodesMapper.modelToDto(apv.getUser().getRoleConfig()));
            appraiseVehicleDto.setSignDet(signDetMapper.modelToDto(apv.getSignDet()));

            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(acConditionMapper.modelToDto(apv.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition()));

            String filePath=FOLDER_PATH+appraiseVehicleDto.getAppraisalTestDriveStatus().getRearRightImage();
            byte[] image= Files.readAllBytes(new File(filePath).toPath());

            String base64EncodedImage = Base64.getEncoder().encodeToString(image);


//            String base64EncodedImage = Base64.getEncoder().encodeToString(image);
//            byte[] base64DecodedImage = Base64.getDecoder().decode(base64EncodedImage);


            // Set the response headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_JPEG);
            headers.setContentLength(base64EncodedImage.length());

            // Create the response entity with the DTO object and image file as the body
            ResponseEntity<String> responseEntity = new ResponseEntity<String>(base64EncodedImage, headers, HttpStatus.OK);

            // Set the DTO object as a response header
            responseEntity.getHeaders().add("appraiseVehicle_DTO", new ObjectMapper().writeValueAsString(appraiseVehicleDto));

            return responseEntity;

         //   return appraiseVehicleDto;
        }
        else throw new RuntimeException("Did not find AppraisalVehicle of  - " + vinNum);

    }

    @Override
    public AppraiseVehicle updateAppraisalVehicle(AppraiseVehicle eAppraiseVehicledto, MultipartFile rightImage) throws IOException{


        EAppraiseVehicle vehicle = eAppraiseVehicleRepo.findByVinNumber(eAppraiseVehicledto.getVinNumber());
        if(vehicle!=null){

            if(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalRef()==null){

                eAppraiseVehicledto.getAppraisalTestDriveStatus().setAppraisalRef(appraisalVehicleMapper.modelToDto(vehicle));

            }

            if(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition().getVehicleStatus()==null) {

                eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition().setVehicleStatus(eAppraiseVehicledto.getAppraisalTestDriveStatus());
            }


             //add new file
            String extension = FilenameUtils.getExtension(rightImage.getOriginalFilename());
            String filename = UUID.randomUUID().toString() +"."+ extension;
            Path filePath = Paths.get(FOLDER_PATH + filename);


            Files.write(filePath, rightImage.getBytes()); //sending to folder

            //delete old file
            String old = FOLDER_PATH + vehicle.getAppraisalTestDriveStatus().getRearRightImage();
            Path filePathOld = Paths.get(old);
            Files.delete(filePathOld);


            eAppraiseVehicledto.getAppraisalTestDriveStatus().setRearRightImage(filename);      //setting to object


            vehicle.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus()));
           vehicle.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(acConditionMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition()));

            eAppraiseVehicleRepo.save(vehicle);

             AppraiseVehicle appraiseVehicleDto= appraisalVehicleMapper.modelToDto(vehicle);

            appraiseVehicleDto.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(vehicle.getAppraisalTestDriveStatus()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(acConditionMapper.modelToDto(vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition()));


            return appraiseVehicleDto;

        }

       else throw new RuntimeException("Did not find AppraisalVehicle of "+eAppraiseVehicledto.getVinNumber() );

    }

    @Override
    public String deleteAppraisalVehicle(String vinNum) {
        EAppraiseVehicle byVinNumber = eAppraiseVehicleRepo.findByVinNumber(vinNum);
        if(byVinNumber!=null) {
            byVinNumber.setValid(false);
            eAppraiseVehicleRepo.save(byVinNumber);

            return "deleted";
        }
        else
        throw new RuntimeException("Did not find AppraisalVehicle of  - " + vinNum);
    }
}
