package com.factory.appraisal.vehiclesearchapp.services;
//Author:Rupesh khade
import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EAppraiseVehicleServiceImpl implements EAppraiseVehicleService {
    @Autowired
    EAppraiseVehicleRepo eAppraiseVehicleRepo;
    @Autowired
    EConfigurationCodesRepo eConfigurationCodesRepo;
    @Autowired
    EAppraisalTestDriveStatusRepo eAppraisalTestDriveStatusRepo;
    @Autowired
    EUserRegistrationRepo eUserRegistrationRepo;
    @Autowired
    EDealerRegistrationRepo eDealerRegistrationRepo;
    @Autowired
    private ESignDetRepo eSignDetRepo;

    @Override
    public List<EAppraiseVehicle> GetAppraisals() {
        return (List<EAppraiseVehicle>)eAppraiseVehicleRepo.findAll();
    }

    @Override
    public EAppraiseVehicle addAppraiseVehicle(EAppraiseVehicle eAppraiseVehicle) {

        eAppraiseVehicle.getDealerId().setCodeId(eAppraiseVehicle.getUserId().getRoleId());
        eAppraiseVehicle.getUserId().setRoleId(eAppraiseVehicle.getUserId().getRoleId());
        eAppraiseVehicle.getUserId().setDealerId(eAppraiseVehicle.getDealerId());
        eAppraiseVehicle.setUserId(eAppraiseVehicle.getUserId());
        eAppraiseVehicle.setDealerId(eAppraiseVehicle.getDealerId());
        eAppraiseVehicle.setAppraisalTestDriveStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());
        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalRef(eAppraiseVehicle);


       eConfigurationCodesRepo.save(eAppraiseVehicle.getUserId().getRoleId());
       eUserRegistrationRepo.save(eAppraiseVehicle.getUserId());
       eDealerRegistrationRepo.save(eAppraiseVehicle.getDealerId());
        EAppraiseVehicle eAppraiseVehicle1=eAppraiseVehicleRepo.save(eAppraiseVehicle);
       eAppraisalTestDriveStatusRepo.save(eAppraiseVehicle.getAppraisalTestDriveStatus());


       return eAppraiseVehicle1;

    }
    @Override
    public EAppraiseVehicle findByVinNumber(String vinNum) {

        return eAppraiseVehicleRepo.findByVinNumber(vinNum);
    }

    @Override
    public EAppraiseVehicle updateAppraisalVehicle(EAppraiseVehicle eAppraiseVehicle,String vinNum) {
        EAppraiseVehicle vehicle = eAppraiseVehicleRepo.findByVinNumber(vinNum);
        if(vehicle!=null){
            eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalRef(vehicle);

           vehicle.setAppraisalTestDriveStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());
           eAppraiseVehicleRepo.save(vehicle);

           eAppraisalTestDriveStatusRepo.save(vehicle.getAppraisalTestDriveStatus());

            return vehicle;
        }

       else throw new RuntimeException("Did not find AppraisalVehicle of  - " + vinNum);

    }

    @Override
    public String deleteAppraisalVehicle(String vinNum) {
        EAppraiseVehicle byVinNumber = eAppraiseVehicleRepo.findByVinNumber(vinNum);
        if(byVinNumber!=null) {

            eAppraiseVehicleRepo.deleteById(byVinNumber.getAppraisalReferenceId());
            return "deleted";
        }
        else
        throw new RuntimeException("Did not find AppraisalVehicle of  - " + vinNum);
    }
}
