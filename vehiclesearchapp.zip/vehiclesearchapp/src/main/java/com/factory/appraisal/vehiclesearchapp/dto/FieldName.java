package com.factory.appraisal.vehiclesearchapp.dto;
//Author :Kalyan

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class FieldName {

    //user/dealer
    String clientFirstName;
    String clientLastName;
    String phoneNumber;
    String dealershipUserNames;

    //AppraisalVehicle
    String vinNumber;
    String vehicleYear;
    String vehicleMake;
    String vehicleModel;
    String vehicleSeries;
    String vehicleMileage;

    //AppraisalTestDriveStatus
    String engineType;
    String transmissionType;

    //Test Drive Status
    List<String> vehicleExteriorColor;

    //vehicleInterior
    List<String> vehicleInterior;

    //VehicleDrivingWarnLightStatus
    List<String> dashWarningLights;

    //AppraisalVehicleAcCondition
    List<String> acCondition;

    //AppraisalTestDriveStatus
    List<String> doorLocks;
    List<String> roofType;

    //AppraisalVehicleStereoStatus
    List<String> stereoStatus;
    List<String> interiorCondition;

    //AppraisalTestDriveStatus
    List<String> leftFrontWindowStatus;
    List<String> frontRightWindowStatus;
    List<String> rearLeftWindowStatus;
    List<String> rearRightWindowStatus;

    //
    String quickAppraisal;

    //picture
    String vehiclePicture1;
    String vehiclePicture2;
    String vehiclePicture3;
    String vehiclePicture4;
    String vehiclePicture5;
    String vehiclePicture6;
    String vehiclePicture7;
    String vehiclePicture8;
    String vehiclePicture9;
    String vehicleVideo1;

    //AppraisalVehicleOilCondition

    List<String> oilCondition;

//Appraisal test Drive status
    String externalDamage;

    //AppraisalTestDriveStatus
    String frontDriversideDamage;
    String frontDriversideDamageTextBox;
    String frontDriversideDamagePicture;
    String rearDriversideDamage;
    String rearDriversideDamageTextBox;
    String rearDriversideDamagePicture;
    String rearPassengerSideDamage;
    String rearPassengerSideDamageTextBox;
    String rearPassengerSideDamagePicture;
    String frontPassengerSideDamage;
    String frontPassengerSideDamageTextBox;
    String frontPassengerSideDamagePicture;
    String paintWork;
    String frontDriversidePaintwork;
    String frontDriversidePaintworkTextBox;
    String frontDriversidePaintworkPicture;
    String rearDriversidePaintwork;
    String rearDriversidePaintworkTextBox;
    String rearDriversidePaintworkPicture;
    String rearPassengerSidePaintwork;
    String rearPassengerSidePaintworkTextBox;
    String rearPassengerSidePaintworkPicture;
    String frontPassengerSidePaintwork;
    String frontPassengerSidePaintworkTextBox;
    String frontPassengerSidePaintworkPicture;
    List<String> frontWindshieldDamage;
    List<String> rearGlassDamage;

    //

    String keyAssureYes;
    String subscribToKeyAssure;
    String keyAssureFiles;
    List<String> brakingSystemStatus;

    //Appraisal vehicle
    List<String> enginePerformance;
    List<String> transmissionStatus;

    //AppraisalTest Drive Status
    List<String> steeringFeelStatus;

//
    List<String> booksAndKeys;
    List<String> titleStatus;

    String professionalOpinion;

    //ConfigurationCodes
    String vehicleDescription;

    String eSign;
//
    String adjustedWholsalePoor;
    String adjustedWholesaleFair;
    String adjustedWholesaleGood;
    String adjustedWholesaleVeryGood;
    String adjustedWholesaleExcellent;
    String adjustedFinancePoor;
    String adjustedFinanceFair;
    String adjustedFinanceGood;
    String adjustedFinanceVeryGood;
    String adjustedFinanceExcellent;
    String adjustedRetailPoor;
    String adjustedRetailFair;
    String adjustedRetailGood;
    String adjustedRetailVeryGood;
    String adjustedRetailExcellent;

    //AppraisalVehicle
    String appraisedValue;

//
    String dealerReserve;
    String comsumerAskingPrice;
    String dealerRetailAskingPric;


//
    String pushforBuyfigure;

}
