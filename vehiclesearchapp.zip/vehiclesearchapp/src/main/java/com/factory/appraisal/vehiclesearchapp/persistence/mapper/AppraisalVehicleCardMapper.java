package com.factory.appraisal.vehiclesearchapp.persistence.mapper;

import com.factory.appraisal.vehiclesearchapp.dto.AppraisalVehicleCard;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AppraisalVehicleCardMapper {

    AppraisalVehicleCard modelToDto(EAppraiseVehicle eAppraiseVehicle);
    List<AppraisalVehicleCard> modelsToDtos(List<EAppraiseVehicle> eAppraiseVehicleList);
}
