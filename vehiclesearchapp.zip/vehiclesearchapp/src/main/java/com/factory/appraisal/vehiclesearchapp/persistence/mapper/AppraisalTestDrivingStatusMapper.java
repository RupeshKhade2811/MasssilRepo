package com.factory.appraisal.vehiclesearchapp.persistence.mapper;
//@author:Rupesh Khade

import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraisalTestDriveStatus;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraisalTestDriveStatus;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface AppraisalTestDrivingStatusMapper {

    EAppraisalTestDriveStatus dtoToModel(AppraisalTestDriveStatus appraisalTestDrivingStatus);
    @Mapping(target = "appraisalRef",ignore = true)
    @Mapping(target = "appraisalVehicleAcCondition",ignore = true)
    @Mapping(target = "appraisalVehicleInteriorCondition",ignore = true)
    @Mapping(target = "appraisalVehicleOilCondition",ignore = true)
    @Mapping(target = "appraisalVehicleStereoStatus",ignore = true)
    @Mapping(target = "appraisalVehicleTireCondition",ignore = true)
    @Mapping(target = "vehicleDrivingWarnLightStatus",ignore = true)
    AppraisalTestDriveStatus modelToDto(EAppraisalTestDriveStatus eAppraisalTestDrivingStatus);  //ignore  due to  recursion problem in mapstruct, entities having bidirectional relationship

}
