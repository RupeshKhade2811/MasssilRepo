package com.factory.appraisal.vehiclesearchapp.persistence.mapper;

//authorName : YogeshKumarV

import com.factory.appraisal.vehiclesearchapp.dto.AppraisalVehicleTireCondition;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraisalVehicleTireCondition;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface AppraisalVehicleTireConditionMapper {



    AppraisalVehicleTireCondition modelToDto(EAppraisalVehicleTireCondition eAppraisalVehicleTireCondition);


    EAppraisalVehicleTireCondition dtoToModel(AppraisalVehicleTireCondition appraisalVehicleTireCondition);


}
