package com.factory.appraisal.vehiclesearchapp.controller;
//@author:Rupesh Khade

import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.*;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.services.EAppraiseVehicleServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class AppraisalVehicleController {
    @Autowired
    private AppraisalVehicleMapper appraisalVehicleMapper;
    @Autowired
    private DealerRegistrationMapper dealerRegistrationMapper;
    @Autowired
    private UserRegistrationMapper userRegistrationMapper;
    @Autowired
    private AppraisalTestDrivingStatusMapper appraisalTestDrivingStatusMapper;
    @Autowired
    private ConfigCodesMapper  configCodesMapper;
    @Autowired
    private SignDetMapper signDetMapper;
    @Autowired
    private EAppraiseVehicleServiceImpl service;



    @PostMapping("/addAppraiseVehicle")
    public ResponseEntity<AppraiseVehicle> addAppraiseVehicle(@RequestBody AppraiseVehicle appraiseVehicle){



        return new ResponseEntity<>(appraisalVehicleMapper.modelToDto(service.addAppraiseVehicle(appraisalVehicleMapper.dtoToModel(appraiseVehicle))), HttpStatus.ACCEPTED);
    }

    @GetMapping("/getAppraisals")
    public ResponseEntity<List<AppraiseVehicle>> getAppraisals(){
        List<EAppraiseVehicle> apv= service.GetAppraisals();
        List<AppraiseVehicle> appraiseVehicleDtos= appraisalVehicleMapper.modelsToDtos(apv);

        ArrayList<EAppraiseVehicle>al1= new ArrayList<>(apv);
        ArrayList<AppraiseVehicle>al2= new ArrayList<>(appraiseVehicleDtos);
        for(int i=0;i<al1.size();i++){
            al2.get(i).setDealerId(dealerRegistrationMapper.modeltoDto(al1.get(i).getDealerId()));
            al2.get(i).setUserId(userRegistrationMapper.modelToDto(al1.get(i).getUserId()));
            al2.get(i).setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(al1.get(i).getAppraisalTestDriveStatus()));
            al2.get(i).getUserId().setRoleId(configCodesMapper.modelToDto(al1.get(i).getUserId().getRoleId()));
            al2.get(i).setSignDet(signDetMapper.modelToDto(al1.get(i).getSignDet()));
        }

        List<AppraiseVehicle> appraiseVehicleDtos1=al2;


        return new ResponseEntity<>(appraiseVehicleDtos1,HttpStatus.ACCEPTED);

    }

    @GetMapping("/getAppraisal/{vinNum}")
    public ResponseEntity<AppraiseVehicle> showAppraisalVehicle(@PathVariable String vinNum){
       EAppraiseVehicle apv= service.findByVinNumber(vinNum);

        AppraiseVehicle appraiseVehicleDto= appraisalVehicleMapper.modelToDto(apv);

        appraiseVehicleDto.setDealerId(dealerRegistrationMapper.modeltoDto(apv.getDealerId()));
        appraiseVehicleDto.setUserId(userRegistrationMapper.modelToDto(apv.getUserId()));
        appraiseVehicleDto.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(apv.getAppraisalTestDriveStatus()));
        appraiseVehicleDto.getUserId().setRoleId(configCodesMapper.modelToDto(apv.getUserId().getRoleId()));
        appraiseVehicleDto.setSignDet(signDetMapper.modelToDto(apv.getSignDet()));

        return new ResponseEntity<>(appraiseVehicleDto,HttpStatus.ACCEPTED);

    }

    @PutMapping("/updateAppraisalVehicle/{vinNum}")
    public ResponseEntity<AppraiseVehicle> updateAppraisalVehicle(@RequestBody AppraiseVehicle appraiseVehicle,
                                                                  @PathVariable String vinNum) {
        EAppraiseVehicle apv= service.updateAppraisalVehicle(appraisalVehicleMapper.dtoToModel(appraiseVehicle),vinNum);
        AppraiseVehicle appraiseVehicleDto= appraisalVehicleMapper.modelToDto(apv);

        appraiseVehicleDto.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(apv.getAppraisalTestDriveStatus()));

        return new ResponseEntity<>(appraiseVehicleDto,HttpStatus.ACCEPTED);
    }

    @DeleteMapping("/deleteAppraisal/{vinNum}")
    public String deleteAppraisal(@PathVariable String vinNum){
        return  service.deleteAppraisalVehicle(vinNum);
    }

}
