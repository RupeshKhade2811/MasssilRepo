package com.factory.appraisal.vehiclesearchapp.controller;
//@author:Rupesh Khade

import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraiseVehicle;

import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.services.EAppraiseVehicleServiceImpl;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.IOException;

import java.util.List;

@RestController
@RequestMapping("/api/appraisal")
public class AppraisalVehicleController {

    @Autowired
    private EAppraiseVehicleServiceImpl service;


    @ApiOperation(value = "Add Appraisal", response = AppraiseVehicle.class)
    @PostMapping("/addAppraiseVehicle")
    public ResponseEntity<AppraiseVehicle> addAppraiseVehicle(@RequestPart("data") @Valid AppraiseVehicle appraiseVehicle, @RequestPart("rightImage") MultipartFile rightImage) throws IOException {

        return new ResponseEntity<>(service.addAppraiseVehicle(appraiseVehicle,rightImage), HttpStatus.ACCEPTED);
    }

    @GetMapping("/getAppraisals/{pageNumber}/{pageSize}")
    public ResponseEntity<List<AppraiseVehicle>> getAppraisals(@PathVariable Integer pageNumber, @PathVariable Integer pageSize){

        List<AppraiseVehicle> apv= service.GetAppraisals(pageNumber,  pageSize);


        return new ResponseEntity<>(apv,HttpStatus.ACCEPTED);

    }

    @ApiOperation(value = "Get Appraisal by vinNumber", response = EAppraiseVehicle.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved EAppraiseVehicle.class"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    })
    @GetMapping(value = "/getAppraisal/{vinNum}")
    public  ResponseEntity<byte[]> showAppraisalVehicle(@PathVariable String vinNum)throws IOException{
     //  AppraiseVehicle appraiseVehicleDto= service.findByVinNumber(vinNum);



            return service.findByVinNumber(vinNum);
    }

    @PutMapping("/updateAppraisalVehicle/{vinNum}")
    public ResponseEntity<AppraiseVehicle> updateAppraisalVehicle( @RequestPart("data") @Valid AppraiseVehicle appraiseVehicle,@RequestPart("rightImage") MultipartFile rightImage) throws IOException{
        AppraiseVehicle appraiseVehicleDto= service.updateAppraisalVehicle(appraiseVehicle,rightImage);
        return new ResponseEntity<>(appraiseVehicleDto,HttpStatus.ACCEPTED);
    }

    @DeleteMapping("/deleteAppraisal/{vinNum}")
    public String deleteAppraisal(@PathVariable String vinNum){
        return  service.deleteAppraisalVehicle(vinNum);
    }

}
