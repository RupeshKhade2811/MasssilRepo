package com.factory.appraisal.vehiclesearchapp.persistence.mapper;


import com.factory.appraisal.vehiclesearchapp.dto.AppraisalVehicleOilCondition;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraisalVehicleOilCondition;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface AppraisalVehicleOilConditionMapper {

    AppraisalTestDrivingStatusWithBaseClassMapper INSTANCE = Mappers.getMapper(AppraisalTestDrivingStatusWithBaseClassMapper.class);



    AppraisalVehicleOilCondition modelToDto(EAppraisalVehicleOilCondition eAppraisalVehicleOilCondition);

    EAppraisalVehicleOilCondition dtoToModel(AppraisalVehicleOilCondition appraisalVehicleOilCondition);




}
