package com.factory.appraisal.vehiclesearchapp.persistence.mapper;


import com.factory.appraisal.vehiclesearchapp.dto.AppraisalVehicleInteriorCondition;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraisalVehicleInteriorCondition;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface AppraisalVehicleInteriorConditionMapper {

    AppraisalTestDrivingStatusWithBaseClassMapper INSTANCE = Mappers.getMapper(AppraisalTestDrivingStatusWithBaseClassMapper.class);



    AppraisalVehicleInteriorCondition modelToDto(EAppraisalVehicleInteriorCondition eAppraisalVehicleInteriorCondition);


    EAppraisalVehicleInteriorCondition dtoToModel(AppraisalVehicleInteriorCondition appraisalVehicleInteriorCondition);


}
